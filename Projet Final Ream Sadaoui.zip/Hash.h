#define __HASH_H__
#include <stdio.h>
#include "Reseau.h"

//Q 4.1 management of collisions by chaining okokokook
#define SIZE 100
struct cellnode* hashArray[SIZE];
struct cellnode* dummyItem;
struct cellnode* item;



void printHashTable();
void insert(int key,Noeud *ndr);
struct cellnode *search(int key);
int hashCode(int key);
void generateFileWithHashTable();
struct CellNode * getUniqueChaineFromHashTable(struct cellnode* hashArray[]);
